$(document).ready(function(){
	
	$('.timeline, .left, .right').css('height', $( window ).height() -70);

	$(".addperson1").click(function() {

		$(".timeline-posts").prepend(" <div class='timeline-post'><img src='images/Erik_Hekman.png' alt=''><h3>Erik Hekman <span class='new'>Nieuw!</span></h3><p>Net terug uit Chili :D</p><button class='removeperson removeperson1'>-</button></div>");
		$(this).parent().slideUp();
		$(this).remove();
	});

	$(".addperson2").click(function() {

		$(".timeline-posts").prepend(" <div class='timeline-post'><img src='images/tifalockheart.png' alt=''><h3>Tifa Lockheart <span class='new'>Nieuw!</span></h3><p>Have faith and all will be good.</p><button class='removeperson removeperson2'>-</button></div>");
		$(this).parent().slideUp();
		$(this).remove();
	});

	$(document).on('click', '.removeperson1', function() {

		$(this).parent().slideUp();
		$(this).remove();
		$(".new-people").prepend("<div class='new-person person1'><img src='images/Erik_Hekman.png' alt=''><h3>Erik Hekman </h3><p>Net terug uit Chili :D</p><button class='addperson addperson1'>+</button></div>");
	});

	$(document).on('click', '.removeperson2', function() {

		$(this).parent().slideUp();
		$(this).remove();
		$(".new-people").prepend("<div class='new-person person2'><img src='images/tifalockheart.png' alt=''><h3>Tifa Lockheart </h3><p>Have faith and all will be good.</p><button class='addperson addperson1'>+</button></div>");
	});


$('.person1 h3').magnificPopup({
    items: [
      {
        src: '#person1-popup', // CSS selector of an element on page that should be used as a popup
        type: 'inline'
      }
    ]
});
$('.person2 h3').magnificPopup({
    items: [
      {
        src: '#person2-popup', // CSS selector of an element on page that should be used as a popup
        type: 'inline'
      }
    ]
});



});




function readURL(input) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();

		reader.onload = function (e) {
			$('.current-person').css('background', '#f9873d url('+e.target.result +') center center no-repeat');
		}

		reader.readAsDataURL(input.files[0]);
	}
}













// function autosize(textarea) {
//     $(textarea).height(1); // temporarily shrink textarea so that scrollHeight returns content height when content does not fill textarea
//     $(textarea).height($(textarea).prop("scrollHeight"));
// }


// $(document).ready(function () {
// 	$(document).on("input", "textarea", function() {
// 		autosize(this);
// 	});
// 	$("textarea").each(function () {
// 		autosize(this);
// 	});
// });



